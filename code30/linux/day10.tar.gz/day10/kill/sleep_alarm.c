#include <func.h>

int main(int argc,char* argv[])
{
    alarm(3);
    sleep(10);
    return 0;
}

