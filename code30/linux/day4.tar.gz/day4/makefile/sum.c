#include <func.h>

int sum(int a,int b)
{
    printf("sum=%d\n",a+b);
    return 0;
}

