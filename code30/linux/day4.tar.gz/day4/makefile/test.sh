#!/bin/bash

a=5

echo ${a}



