#include <func.h>

int main(int argc,char* argv[])
{
    system("sleep 30");
    return 0;
}

