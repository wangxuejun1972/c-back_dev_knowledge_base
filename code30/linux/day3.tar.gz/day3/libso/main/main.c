#include <func.h>

int add(int,int);
int main()
{
    printf("I am main,sum=%d\n",add(3,4));
    return 0;
}

