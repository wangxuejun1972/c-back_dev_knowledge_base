#include <func.h>

int main()
{
//调试开关
#ifdef DEBUG
    printf("I am debug information\n");
#endif
    return 0;
}

