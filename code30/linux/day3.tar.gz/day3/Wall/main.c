#include <func.h>

int main()
{
    long i=38888;
    short s=i;
    printf("s=%d\n",s);
    return 0;
}

