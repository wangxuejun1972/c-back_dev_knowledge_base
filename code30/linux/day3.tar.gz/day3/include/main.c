#include  "test.h"

int main()
{
    printf("I am main function\n");
    return 0;
}

