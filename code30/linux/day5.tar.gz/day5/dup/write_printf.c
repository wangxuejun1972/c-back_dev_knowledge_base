#include <func.h>

int main(int argc,char* argv[])
{
    write(1,"hello",5);
    return 0;
}

