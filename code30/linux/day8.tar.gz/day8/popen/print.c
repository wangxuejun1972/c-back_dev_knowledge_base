#include <func.h>

int main(int argc,char* argv[])
{
    printf("I am print\n");
    return 0;
}

