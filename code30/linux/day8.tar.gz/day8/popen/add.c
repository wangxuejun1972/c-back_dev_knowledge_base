#include <func.h>

int main(int argc,char* argv[])
{
    int i,j;
    scanf("%d%d",&i,&j);
    printf("sum=%d\n",i+j);
    return 0;
}

